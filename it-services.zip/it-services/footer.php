<?php get_footer(); ?>
</div>
        </div>
    </div>

    <div class="copy_right_footer">
        Developed by IIIT-H
    </div>
    <?php wp_footer(); ?>
</body>
</html>