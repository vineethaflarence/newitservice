
<?php 

?>
<?php wp_head(); ?>

<div class="img-container">
<img src="http://localhost/it-services/wp-content/uploads/2023/11/n.png" class="bg-img" style="width:100%;height:350px;margin-top:20px;" alt="Background Image">
</div>
<div class="container">
<div class="network-content text-center">
<h1 style="color:rgb(43, 57, 78);margin:10px;">Networking</h1>
<div class="line"></div>
<ul class="listing-items ">
    <a href="wired_network.html" class="click-here"><li class="list">Wired Network</li></a>
    <a href="wifi_network.html" class="click-here"><li  class="list" class="click-here">Wifi Network</li></a>
    <li  class="list" class="click-here">Intern Student Internet Connection</li>
    <li  class="list" class="click-here">Internet connection in Hostel for Intern Student</li>
    <li  class="list" class="click-here">VPN Connectivity</li>
    <li  class="list" class="click-here">Connectivity to out side servers</li>
    <li  class="list" class="click-here">WiFi Access for Guests</li>
    <li class="list" class="click-here">VLAN/Subnet for Faculty/Staff</li>
    <li  class="list" class="click-here">Radius Authentication in Research Centres/Hostels</li>
    <li  class="list" class="click-here">How to Determine Your Hardware Address</li>
</ul>
</div>
</div>

<?php wp_footer(); ?>
