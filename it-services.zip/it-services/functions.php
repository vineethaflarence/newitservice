<?php
/**
 * Theme Functions.
 */

/* Theme Setup */
// Enqueue your stylesheet
function enqueue_custom_styles() {
    wp_enqueue_style('theme-style', get_stylesheet_uri());
    // Additional styles can be enqueued here
}
add_action('wp_enqueue_scripts', 'enqueue_custom_styles');
function hide_page_title($title, $id) {
    if (is_page('Networking')) {
        return '';
    }
    return $title;
}
add_filter('the_title', 'hide_page_title', 10, 2);

function remove_edit_link($link) {
    return '';
}
add_filter('edit_post_link', 'remove_edit_link');
?>