
<?php

?>
<footer id="footer">
	<div class="container">
		<div class="ad-bloc" id="contactus">
		  <b>For queries please contact us at:</b><br>
				UG Admissions <br>
				IIIT Hyderabad, Gachibowli<br>
				Hyderabad - 500 032<br>
				<strong class="strong-cls">Email:</strong> <a class="a-links" href="mailto:ugadmissions@iiit.ac.in">ugadmissions@iiit.ac.in</a><br>
				<strong class="strong-cls">Phone:</strong> <span><a href="tel:+914066531250">+91 (40) 6653 1250</a>,<a href="tel:+914066531337"> 6653 1337</a></span><br>
		<strong class="strong-cls">Office timings:</strong> Monday to Saturday, 10 AM to 5 PM(IST).<br>
	   </div>
   </div>
  </footer>
 </body>
</html>
