<?php get_header();?>
<main id="main">
  <section class="section section-bg">
	<div class="container">
	
		<div class="section-title">
		  <h2 class="page-title"><?php the_title();?></h2>
		</div>
		
		<?php get_template_part('includes/section','content');?>
		
	</div>
</section> 
    
  </main>

<?php wp_footer();?>
<?php get_footer();?>
