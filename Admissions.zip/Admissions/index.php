<?php get_header(); ?>

  <main>
    <div class="bd-main">
    <div class="bd-cont container">
      <div class="row">
      <div class="bg-ss">
        <div class="top-img">
          <div class="img-bar-top"></div>
          <img src="images/banner.png" alt="Undergraduate Admissions" width="100%"  title="Undergraduate Admissions" class="Undergraduate-admissions-img">
          <div class="img-bar"></div>
        </div>
         <br />

         <div id="covidnotes" class="note-con" style="background:#ffffe0;">
            <p class="note-para"> 4th November 2020: <strong>Admissions 2020 is now officially over.</strong><br />
            <a data-toggle="collapse" data-target="#collapseNotes" href="#collapseNotes">...</a></p>

            <div id="collapseNotes" class="collapse" data-parent="#covidnotes">
            <p class="note-para small"> <strong>COVID-19 Notice (20th May 2020):</strong> <br> The UGEE, SPEC and LEEE exams have 
            been rescheduled to 24<sup>th</sup> June 2020. The portal 
            will be reopened in the first week of June to allow 
            applicants to make any change to their exam centre preferences.<br />
            </p>
            <p class="note-para small"> <strong>COVID-19 Notice (27th April 2020):</strong> <br>
            Olympiad/KVPY and SPEC mode portal will be closed on 
            15<sup>th</sup> May 2020.
            </p>
            <p class="note-para small"> <strong>COVID-19 Notice (1st April 2020):</strong> <br>
            The UGEE, SPEC and LEEE exams slated to be held on 
            26<sup>th</sup> April 2020 are postponed. The new date for 
            the exams will be announced in due course of time. 
            Applicants are advised to visit the page frequently. 
            Further, the closing date for UGEE and LEEE application 
            portals is extended until 27<sup>th</sup> April 2020. 
            </p>
            </div>
          </div>
        <div class="tg-down tg-left">
          <ul class="tg-cont tg-up col-12 col-md-8 col-xl-9">
            <li class="tg-sub col-12  col-sm-6 col-xl-4">
            <a href="https://ugadmissions.iiit.ac.in/ugee_page.html">
              <img src="images/blue.png" alt="" class="ad-img">
              <div class="middle-te">
                <h4 class="text-4">Undergraduate Entrance Exam(UGEE)</h4>
                <p class="st-para">For all Dual-degree Programmes</p>
              </div>
              <img src="images/blue1.png" class="ad-img" alt="">
              </a>
            </li>
            <li class="tg-sub col-12 col-sm-6 col-xl-4">
            <a href="https://ugadmissions.iiit.ac.in/spec_page.html">
              <img src="images/purple.png" alt="" class="ad-img">
              <div class="middle-te sec">
                <h4 class="text-4">Special Channel of Admission(SPEC)</h4>
                <p class="st-para">For Single-degree Programmes</p>
              </div>
              <img src="https://ugadmissions.iiit.ac.in/images/purple1.png" class="ad-img" alt="">
              </a>
            </li>
            <li class="tg-sub col-12 col-sm-6 col-xl-4">
              <a href="leee_page.html">
              <img src="images/pink.png" class="ad-img" alt="">
              <div class="middle-te third">
                <h4 class="text-4">Lateral Entry Entrance Exam(LEEE)</h4>
                <p class="st-para">For Dual-degree Programmes</p>
              </div>
              <img src="images/pink1.png" class="ad-img" alt="">
            </a>
            </li>
            <li class="tg-sub left col-12 col-xl-3">
              <img src="images/left.png" width="127" height="70" alt="" class="left-cs">
            </li>
            <li class="tg-sub title col-12 col-xl-6">
              <h4 class="admissions">Modes of Undergraduate Admissions</h4>
            </li>
            <li class="tg-sub right col-12 col-xl-3">
              <img src="images/right.png" width="127" height="70" alt="" class="right-cs">
            </li>
            <li class="tg-sub col-12 col-sm-6 col-xl-4">
            <a href="olympiad_page.html">
              <img src="images/green1.png" class="ad-img" alt="">
              <div class="middle-te four">
                <h4 class="text-4">Olympiad/KVPY</h4>
                <p class="st-para">For Dual-degree Programmes</p>
              </div>
              <img src="images/green.png" class="ad-img" alt="">
              </a>
            </li>
            <li class="tg-sub col-12 col-sm-6 col-xl-4">
	    <a href="dasa_page.html">
              <img src="images/orange1.png" class="ad-img" alt="">
              <div class="middle-te five">
                <h4 class="text-4">Direct Admissions for Students Abroad(DASA)</h4>
                <p class="st-para">For Single-degree and Dual-degree Programmes</p>
              </div>
              <img src="images/orange.png" class="ad-img" alt="">
	      </a>	
            </li>
		
            <li class="tg-sub col-12 col-sm-6 col-xl-4">
	     <a href="jee_page.html">
              <img src="images/gray1.png" class="ad-img" alt="">
              <div class="middle-te six">
                <h4 class="text-4">JEE (Main)</h4>
                <p class="st-para">For Single-degree Programmes</p>
              </div>
              <img src="images/gray.png" class="ad-img" alt="">
	      </a>	
            </li>
          </ul>
          <ul class="tg-cont tg-annc col-12 col-sm-12 col-md-4 col-xl-3">
                <div id="accordion">
        				<!--<div class="card">
        				  <div class="card-header h-one">
        					<a class="card-link fadeInLeft" data-toggle="collapse" href="#collapseOne">
        					  JEE (Main)
        					</a>
        				  </div>
        				  <div id="collapseOne" class="collapse show" data-parent="#accordion">
        					<div class="card-body">
        					  <p class="portal-up">Will open in April 2020</p>
        					</div>
        				  </div>
        				</div>

        				<div class="card">
        				  <div class="card-header h-tw">
        					<a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseTwo">
        					(SPEC)
        				  </a>
        				  </div>
        				  <div id="collapseTwo" class="collapse" data-parent="#accordion">
        					<div class="card-body">
        					  <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
                    <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
                    <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
        					</div>
        				  </div>
        				</div>
        				<div class="card">
        				  <div class="card-header h-three">
        					<a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseThree">
        					  (LEEE)
        					</a>
        				  </div>
        				  <div id="collapseThree" class="collapse" data-parent="#accordion">
        					<div class="card-body">
        					  <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
                    <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
                    <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
        					</div>
        				  </div>
        				</div>
        				<div class="card">
        				  <div class="card-header h-four">
        					<a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapsefour">
        					  Olympiad/KVPY
        					</a>
        				  </div>
        				  <div id="collapsefour" class="collapse" data-parent="#accordion">
        					<div class="card-body">
        					  <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
                    <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
                    <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
        					</div>
        				  </div>
        				</div>
        				<div class="card">
        				  <div class="card-header h-five">
        					<a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseFive">
        					  (DASA)
        					</a>
        				  </div>
        				  <div id="collapseFive" class="collapse" data-parent="#accordion">
        					<div class="card-body">
        					  <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
                    <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
                    <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
        					</div>
        				  </div>
        				</div>-->



        				<div class="card">
        				  <div class="card-header h-six">
        					<a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseSix">
        					  JEE (Main)
        					</a>
        				  </div>
        				  <div id="collapseSix" class="collapse show" data-parent="#accordion">
        					<div class="card-body">
                    <p class="portal-up">Round 4 Results Announced</p>
        					</div>
        				  </div>
        				</div>
        			  </div>
          </ul>
        </div>
           <div class="note-con">
            <p class="note-para"> <strong>Important Note:</strong> <br>All admissions to IIIT Hyderabad are handled directly through the portals on our website. We do NOT have any other companies or online portals representing us and providing indirect admission services. Any claim(s) by such companies is completely false.</p>
          </div>
        <div class="hm-blog tg-cont">
          <div class="hm-blog-sub col-xs-12 col-md-4">
            <h3 class="bg-text">CORE DUAL DEGREE PROGRAMMES</h3>
            <a href="https://www.youtube.com/watch?v=9q5rvGVYN9c"><img src="images/Electronics-&amp;-Communication-Engineering-Program.png" width="174" height="114" alt=""></a>
            <div class="text-up">
            <a href="https://www.youtube.com/watch?v=9q5rvGVYN9c" onmouseover="this.style.color='#ff2a00'" onmouseout="this.style.color='#333333'" style="font-family: Arial, Verdana, Helvetica; font-size: 14px; color: rgb(51, 5(UGEE1, 51); text-decoration: none;">B.Tech and Master of Science by Research in Electronics &amp; Communication Engineering/Computer Science Engineering </a></div>
          </div>
          <div class="hm-blog-sub col-xs-12 col-md-8">
            <h3 class="bg-text">INTERDISCIPLINARY DUAL DEGREE PROGRAMMES</h3>
            <div class="degree-bl">
              <div class="degree-bl-sub col">
                <a class="su-text" href="https://www.youtube.com/watch?v=yzMd8Sbz8SI"><img src="images/Science-in-Computational-linguistics-by-Research.png" width="174" height="114" alt=""></a>
                <div class="text-up">
                <a class="su-text" href="https://www.youtube.com/watch?v=yzMd8Sbz8SI" onmouseover="this.style.color='#ff2a00'" onmouseout="this.style.color='#333333'" style="font-family: Arial, Verdana, Helvetica; font-size: 14px; color: rgb(51, 51, 51); text-decoration: none;">B.Tech in Computer Science &amp; Master of Science in Computational Linguistics by Research</a></div>
              </div>
              <div class="degree-bl-sub col">
                <a href="https://www.youtube.com/watch?v=KuJc3pEWroo"><img src="images/Computational-Natural-Sciences-by-Research-Dual-Degree.png" width="174" height="114" alt=""></a>
                <div class="text-up"><a class="su-text" href="https://www.youtube.com/watch?v=KuJc3pEWroo" onmouseover="this.style.color='#ff2a00'" onmouseout="this.style.color='#333333'" style="font-family: Arial, Verdana, Helvetica; font-size: 14px; color: rgb(51, 51, 51); text-decoration: none;">B.Tech in Computer Science &amp; MS in Computational Natural Sciences by Research Dual Degree</a></div>
              </div>
              <div class="degree-bl-sub col">
                <a href="https://youtu.be/ffBvi4FUB3A"><img src="images/Computing-&amp;-Human-Sciences-by-Research.png" width="174" height="114" alt=""></a>
                <div class="text-up"><a class="su-text" href="https://youtu.be/ffBvi4FUB3A" onmouseover="this.style.color='#ff2a00'" onmouseout="this.style.color='#333333'" style="font-family: Arial, Verdana, Helvetica; font-size: 14px; color: rgb(51, 51, 51); text-decoration: none;">B.Tech in Computer Science &amp; M.S in Computing &amp; Human Sciences by Research  </a></div>
              </div>
            </div>
          </div>
        </div>
        <div class="fee-structure">
          <div class="row">
            <div class="fee-inner col-12 col-md-4"><a href="https://www.iiit.ac.in/admissions/undergraduate/fee-jee-spec">Fee for the Academic Year 2021-22 - Single Degree</a></div>
            <div class="fee-inner col-12 col-md-4"><a href="https://www.iiit.ac.in/admissions/undergraduate/ugee-oly-kvpy-leee">Fee for the Academic Year 2021-22 - Dual Degree </a></div>
            <div class="fee-inner col-12 col-md-4"><a href="https://www.iiit.ac.in/admissions/undergraduate/assistance">Financial Assistance</a></div>
          </div>
        </div>
        <div class="ad-bloc">
          <b>For queries please contact us at:</b><br>
                UG Admissions <br>
                IIIT Hyderabad, Gachibowli<br>
                Hyderabad - 500 032<br>
                Email: <a href="mailto:ugadmissions@iiit.ac.in">ugadmissions@iiit.ac.in</a><br/>
                Phone: +91 (40) 6653 1250, 6653 1337<br/>
		Office timings: Monday to Saturday, 10 AM to 5 PM.<br/>
        </div>
        <div class="ft-do">Updated on April 2020</div>
    </div>
   </div>
  </div>
  </div>
  </main>

<?php get_footer(); ?>
