<?php 
/* Template Name: admission_process */
get_header();?>

<?php 

$important_dates = get_field('important_dates');
$announcement = get_field('announcement');
$admissions_info = get_field('admissions_info');
$page_updated_month_and_year = get_field('page_updated_month_and_year');
$page_logo = get_field('page_logo');
$page_id = get_field('page_id');
$process_id = get_field('process_id');
$faq_id=get_field('faq_id')
?>

  <main id="main">
  <div class="dasa-admissions ug-inner <?php echo $page_id ?>">
  <div class="bd-main">
      <div class="dasa bd-cont container">
          <div class="bg-ss">
      <div class="img-bar col-12">
      <div class="row">
        <div class="container">
          <div class="row">
          <div class="col-sm-12 col-md-1 col-lg-5 img-bar-up"></div>
          <div class="col-sm-12 col-md-11 col-lg-7 img-bar-sub">
          <a href="../" class="rlinks">HOME</a>
          <a href="https://admportal.iiit.ac.in/admissions.php" class="rlinks">APPLICATION</a>
		  <?php if( $process_id ): ?>
			   <a href="<?php echo $process_id ?>" class="rlinks active">ADMISSIONS PROCESS</a>
		   <?php endif; ?>  
			   <?php if($faq_id): ?>
			  <a href="<?php echo $faq_id ?>" class="rlinks active">FAQ</a>
			  <?php endif; ?>
          <a href="#contactus" class="rlinks">CONTACT US</a>
          </div>
         </div>
         </div>
        </div>
      </div>
      <div class="header-con col-12">
        <div class="row">
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-3 hd-logo">
            <img src="<?php echo $page_logo ?>" width="100%" height="123" alt="" class="site-logo">
            </div>
            <div class="col-sm-12 col-md-9 hd-text" style="font-family: 'Open Sans', Arial, Verdana, Articulate;">
            <?php echo get_the_title(); ?>
            </div>
          </div>
        </div>
      </div>
      </div>
      <div class="bd-bottom"></div>
      <div class="ugee-con">
        <div class="ugee-sub border-lef col-12">
          <div class="row">
              <div class="col-12 col-md-3 sec-subs sec up-co">
                 <?php
                  if( have_rows('important_dates') ): ?>
                    <?php while( have_rows('important_dates') ) : the_row();

                      $title   = get_sub_field('title');
                      

                    ?>

                    <ul class="left-sidemenu">
					  <strong class="title-imp">
					     <?php if( !empty( $important_dates['title'] ) ): ?>
						   <?php echo $important_dates['title'] ?>
						 <?php endif; ?>  
						</strong>
                        <?php
                        if( have_rows('information') ): ?>
                          <?php while( have_rows('information') ) : the_row();

                            $date   = get_sub_field('date');
                            $url   = get_sub_field('url');
                            $content   = get_sub_field('content');

                          ?>
						  <?php if( !empty( $content ) ): ?>
                           <li class="left-sideli">
                            <?php if( !empty( $url ) ): ?>
                              <a href="<?php echo $url ?>"><?php endif; ?>
                              <span class="font-weights a-links"><?php echo $content ?>:</span>  
                              <?php if( !empty( $url ) ): ?>
                              </a><?php endif; ?>
                              <span class="span-fo"><?php echo $date ?></span> 
                            </li>
							<?php endif; ?>
                         <?php endwhile; ?>
                        <?php endif; ?>
                      </ul>
                  <?php endwhile; ?>
                  <?php endif; ?>

                  <?php
                  if( have_rows('announcement') ): ?>
                    <?php while( have_rows('announcement') ) : the_row();

                      $title   = get_sub_field('title');
                      

                    ?>

                       <ul class="left-sidemenu">
					     <strong class="title-imp">
						 <?php if( !empty( $announcement['title'] ) ): ?>
						   <?php echo $announcement['title'] ?>
						 <?php endif; ?>  </strong>
                        <?php
                        if( have_rows('information') ): ?>
                          <?php while( have_rows('information') ) : the_row();

                            $date   = get_sub_field('date');
                            $url   = get_sub_field('url');
                            $content   = get_sub_field('content');
                            

                          ?>
						   <?php if( !empty( $content ) ): ?>
                           <li class="left-sideli"><span class="span-fo"><?php echo $date ?>:</span> 
                            <?php if( !empty( $url ) ): ?>
                              <a href="<?php echo $url ?>"><?php endif; ?>
                              <span class="font-weights a-links"><?php echo $content ?></span>
                              <?php if( !empty( $url ) ): ?>
                              </a><?php endif; ?>
                            </li>
							 <?php endif; ?>
                         <?php endwhile; ?>
                        <?php endif; ?>
                      </ul>

                  <?php endwhile; ?>
                  <?php endif; ?>
             
            </div> 
            <div class="col-md-7 col-lg-9 sec-subs first">
              <?php echo $admissions_info ?>
            </div>
            <div class="col-md-5 col-lg-3 sec-subs sec down-co">
               <?php
                  if( have_rows('important_dates') ): ?>
                    <?php while( have_rows('important_dates') ) : the_row();

                      $title   = get_sub_field('title');
                      

                    ?>

                    <ul class="left-sidemenu">
					  <strong class="title-imp">
					    <?php if( !empty( $important_dates['title'] ) ): ?>
						   <?php echo $important_dates['title'] ?>
						 <?php endif; ?>  
					  </strong>
                        <?php
                        if( have_rows('information') ): ?>
                          <?php while( have_rows('information') ) : the_row();

                            $date   = get_sub_field('date');
                            $url   = get_sub_field('url');
                            $content   = get_sub_field('content');

                          ?>
						  <?php if( !empty( $content ) ): ?>
                           <li class="left-sideli">
                            <?php if( !empty( $url ) ): ?>
                              <a href="<?php echo $url ?>"><?php endif; ?>
                              <span class="font-weights a-links"><?php echo $content ?>:</span>  
                              <?php if( !empty( $url ) ): ?>
                              </a><?php endif; ?>
                              <span class="span-fo"><?php echo $date ?></span> 
                            </li>
							<?php endif; ?>
                         <?php endwhile; ?>
                        <?php endif; ?>
                      </ul>
                  <?php endwhile; ?>
                  <?php endif; ?>

                  <?php
                  if( have_rows('announcement') ): ?>
                    <?php while( have_rows('announcement') ) : the_row();

                      $title   = get_sub_field('title');
                      

                    ?>

                       <ul class="left-sidemenu">
					   <strong class="title-imp">
					    <?php if( !empty( $announcement['title'] ) ): ?>
						   <?php echo $announcement['title'] ?>
						 <?php endif; ?>  
					  </strong>
                        <?php
                        if( have_rows('information') ): ?>
                          <?php while( have_rows('information') ) : the_row();

                            $date   = get_sub_field('date');
                            $url   = get_sub_field('url');
                            $content   = get_sub_field('content');
                            

                          ?>
						  <?php if( !empty( $content ) ): ?>
                           <li class="left-sideli"><span class="span-fo"><?php echo $date ?>:</span> 
                            <?php if( !empty( $url ) ): ?>
                              <a href="<?php echo $url ?>"><?php endif; ?>
                              <span class="font-weights a-links"><?php echo $content ?></span>
                              <?php if( !empty( $url ) ): ?>
                              </a><?php endif; ?>
                            </li>
						 <?php endif; ?>
                         <?php endwhile; ?>
                        <?php endif; ?>
                      </ul>

                  <?php endwhile; ?>
                  <?php endif; ?>
            </div>
          </div>
        </div>  
       </div>

      </div>
    </div>
    </div>
  </div>
  </main>
<?php get_footer();?>
<div class="ft-do"><?php echo $page_updated_month_and_year ?></div>
<?php wp_footer();?>
 
    