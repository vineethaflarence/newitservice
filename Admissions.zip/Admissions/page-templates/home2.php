
<?php 
/* Template Name: home2 */
get_header();?>

<?php 

$page_title = get_field('page_title');
$alumni_students = get_field('alumni_students');

?>

  <main id="main">
  <section id="homes" class="homes">
		<div class="container">
		<div class="row">
		<div class="col-md-9">
			<div class="home2 row">
			  <div class="card-inner-section col-md-4">
				<div class="card first">
					<div class="content">
					  <h2 class="title">Undergraduate Entrance Exam(UGEE)</h2>
					  <p class="copy">For all Dual-degree Programmes</p>
					</div>
				</div>
			  </div>
			  <div class="card-inner-section col-md-4">
				  <div class="card second">
					<div class="content">
					  <h2 class="title">Special Channel of Admission(SPEC)</h2>
					  <p class="copy">For Single-degree Programmes</p>
					  
					</div>
				  </div>
			  </div>
			  <div class="card-inner-section col-md-4">
				  <div class="card third">
					<div class="content">
					  <h2 class="title">Lateral Entry Entrance Exam(LEEE)</h2>
					  <p class="copy">For Dual-degree Programmes</p>
					</div>
				  </div>
			  </div>
			  <div class="card-inner-section col-md-4">
				  <div class="card fourth">
					<div class="content">
					  <h2 class="title">Olympiad/KVPY</h2>
					  <p class="copy">For Dual-degree Programmes</p>
					 
					</div>
				  </div>
				  </div>
			</div>
			</div>
			<div class="col-md-3"></div>
		</div>
  </section>
  </main>

<?php wp_footer();?>
<?php get_footer();?>
    