
<?php 
/* Template Name: courses */
get_header();?>

<?php 

$banner = get_field('banner');
$page_updated_month_and_year = get_field('page_updated_month_and_year');
$page_id = get_field('page_id');
$about = get_field('about');

?>

  <main id="main">
    <div class="ug-main">
      <div class="bd-main">
      <div class="bd-cont container">
        <div class="row">
        <div class="bg-ss">
        <div class="top-img">
          <div class="img-bar-top"></div>
          <img src="<?php echo $banner ?>" alt="Undergraduate Admissions" width="100%"  title="Undergraduate Admissions" class="Undergraduate-admissions-img">
          <div class="img-bar"></div>
        </div>
         <br />
		<div class="pagesec-inner courses-se"><?php echo $about ?></div>
      </div>
       </div>
      </div>
    </div>
  </div>
  </main>
<?php get_footer();?>
<div class="ft-do"><?php echo $page_updated_month_and_year ?></div>
<?php wp_footer();?>
 
    