
<?php 
/* Template Name: diversity */
get_header();?>

<link href="<?php bloginfo('template_directory');?>/assets/css/diversity.css?v=1.3" rel="stylesheet">

<?php 

$page_content = get_field('page_content');

?>

<main class="diversity-page">
<div class="container d-flex align-items-center header-diversity"  style="display:none">
    <div class="logo mr-auto"><a href="./diversity"><img  src="http://webdev.iiit.ac.in/admissions2/wp-content/uploads/2022/07/logo.png"/></a></div>
	<div class="mx-5">
	<a href="http://webdev.iiit.ac.in/admissions2/diversity-faqs" target="new" class="mr-3">FAQS</a>
	<a href="#resources1"  class="mr-3">RESOURCES</a>
	<a href="#contact" >CONTACT US</a>
	</div>

	<nav class="nav-menu float-right d-none d-lg-block mr-auto" style="display:none !important">
	
	 
        <ul>
          <li><a href="http://webdev.iiit.ac.in/admissions2/diversity-faqs" target="new">FAQS</a></li>
          <li ><a href="#contact">RESOURCES</a></li>
          <li> <a href="#contact">CONTACT US</a></li>
		  
          <li class="d-md-block d-lg-none">
			  <div class="mobile social-media d-flex">
				<a href="https://www.facebook.com/IIITH" class="fa fa-facebook"></a>
				<a href="https://twitter.com/iiit_hyderabad" class="fa fa-twitter"></a>
				<a href="https://www.instagram.com/iiit.hyderabad/" class="fa fa-instagram"></a>
				<a href=" https://www.linkedin.com/school/49275/admin/" class="fa fa-linkedin"></a>
				<a href="https://www.youtube.com/channel/UCzCMyBy0VRoQBF8x-TsXTnQ" class="fa fa-youtube"></a>  
			   </div>
			</li>
        </ul>
      </nav>
    <div class="desktop social-media d-flex d-md-none d-lg-block">
			<a href="https://www.facebook.com/IIITH" class="fa fa-facebook"></a>
			<a href="https://twitter.com/iiit_hyderabad" class="fa fa-twitter"></a>
			<a href="https://www.instagram.com/iiit.hyderabad/" class="fa fa-instagram"></a>
			<a href=" https://www.linkedin.com/school/49275/admin/" class="fa fa-linkedin"></a>
            <a href="https://www.youtube.com/channel/UCzCMyBy0VRoQBF8x-TsXTnQ" class="fa fa-youtube"></a>  
		</div>
</div>
<?php echo $page_content ?>
<div class="section sec-bg" id="contact" >
<div class="container py-3">
<h3 class="broucher-sec text-center">Contact Us</h3>
<div class="row">
<div class="col-md-6">
<div class="p-2 text-center">
<p>    <strong>UG Admissions</strong></p>
<p dir="ltr">IIIT Hyderabad, Gachibowli,<br>
    Hyderabad – 500 032<br>
    <b>Phone:</b> +91 (40) 6653 1250 and 6653 1337<br>
    <b>Office timings:</b> Monday to Saturday, 10 AM to 5 PM (IST)<br>
    <b>Email:</b>&nbsp;<a href="http://ugadmissions.iiit.ac.in/ugadmissions@iiit.ac.in">ugadmissions@iiit.ac.in</a></p>
<p></p></div>
<p></p></div>
<div class="col-md-6">
<div class="p-2 text-center"><strong>Diversity Admissions<br>
    </strong><p></p>
<p dir="ltr"><b>Phone:</b> +91 (40) 6653 1250 and +91 7702879764<br>
    <b>Office timings:</b> Monday to Saturday, 10 AM to 5 PM (IST)<br>
    <b>Email:</b> <a href="mailto:admissions.diversity@iiit.ac.in">admissions.diversity@iiit.ac.in</a></p>
<p></p></div>
<p></p></div>
<p></p></div>
<p></p></div>
<p></p></div>
<div class="footer-copy">
<div class="container">
<div class="ft-sec"><em>Copyright © 2022, International Institute of Information Technology, Hyderabad. All rights reserved</em></div>
</div>
</div>
</main>
<?php wp_footer();?>
<?php get_footer(); ?>

 
    