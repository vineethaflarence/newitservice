
<!DOCTYPE html>

<html>
    <head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title><?php echo get_the_title(); ?></title>
	<link href="https://fonts.googleapis.com/css?family=Proza+Libre&display=swap" rel="stylesheet">
    <meta content="" name="descriptison">
    <meta content="" name="keywords">
        <?php wp_head();?>
    </head>
<body>
