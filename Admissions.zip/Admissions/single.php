<?php get_header(); ?>

<main id="main">
      <section class="section section-bg">
		  <div class="container">
			<article id="post-<?php the_ID(); ?>">
				<div class="section-title">
					<h2 class="page-title"><?php the_title(); ?></h2>
				</div>
				<div class="section-white">
					<?php the_content(); ?>
				</div>
			 </article>
			<?php if (comments_open() || get_comments_number()) { comments_template(); } ?>
			</div>
       </section>

</main>

<?php wp_footer();?>
<?php get_footer(); ?>
