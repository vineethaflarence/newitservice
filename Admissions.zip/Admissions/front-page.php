<?php get_header();?>

<?php 
  $banner = get_field('banner');
  $announcement = get_field('announcement');
  $modes_list = get_field('announcement');
  $modes_list2 = get_field('modes_list2');
  $important_note_info =  get_field('important_note_info');
  $videos_info =  get_field('videos_info');
  $fee_structure =  get_field('fee_structure');
  $note_points =  get_field('note_points');
  $letest_news =  get_field('letest_news');
  $page_updated_month_and_year = get_field('page_updated_month_and_year');
  
            
?>
<style>
:root {
    --border-radius: 5px;
    --box-shadow: 2px 2px 10px;
    /*--color: #118bee;*/
    --color-accent: #118bee15;
    --color-bg: #fff;
    --color-bg-secondary: #e9e9e9;
    --color-secondary: #920de9;
    --color-secondary-accent: #920de90b;
    --color-shadow: #f4f4f4;
    --color-text: #000;
    --color-text-secondary: #999;
    --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    --hover-brightness: 1.2;
    --justify-important: center;
    --justify-normal: left;
    --line-height: 1.5;
    --width-card: 285px;
    --width-card-medium: 460px;
    --width-card-wide: 800px;
    --width-content: 1080px;
}

/*
@media (prefers-color-scheme: dark) {
    :root {
        --color: #0097fc;
        --color-accent: #0097fc4f;
        --color-bg: #333;
        --color-bg-secondary: #555;
        --color-secondary: #e20de9;
        --color-secondary-accent: #e20de94f;
        --color-shadow: #bbbbbb20;
        --color-text: #f7f7f7;
        --color-text-secondary: #aaa;
    }
}
*/

/* Layout */
article aside {
    background: var(--color-secondary-accent);
    border-left: 4px solid var(--color-secondary);
    padding: 0.01rem 0.8rem;
}

body {
    background: var(--color-bg);
    color: var(--color-text);
    font-family: var(--font-family);
    line-height: var(--line-height);
    margin: 0;
    overflow-x: hidden;
    padding: 1rem 0;
}

footer,
header,
main {
    margin: 0 auto;
    max-width: var(--width-content);
    /*padding: 2rem 1rem;*/
}

hr {
    background-color: var(--color-bg-secondary);
    border: none;
    height: 1px;
    margin: 4rem 0;
}

section {
    display: flex;
    flex-wrap: wrap;
    justify-content: var(--justify-important);
}

section aside {
    border: 1px solid var(--color-bg-secondary);
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow) var(--color-shadow);
    margin: 1rem;
    padding: 1.25rem;
    width: var(--width-card);
}

section aside:hover {
    box-shadow: var(--box-shadow) var(--color-bg-secondary);
}

section aside img {
    max-width: 100%;
}

[hidden] {
    display: none;
}

/* Headers */
article header,
div header,
main header {
    padding-top: 0;
}

header {
    text-align: var(--justify-important);
}

header a b,
header a em,
header a i,
header a strong {
    margin-left: 0.5rem;
    margin-right: 0.5rem;
}

header nav img {
    margin: 1rem 0;
}

section header {
    padding-top: 0;
    width: 100%;
}

/* Nav */
nav {
    align-items: center;
    display: flex;
    font-weight: bold;
    justify-content: space-between;
    margin-bottom: 7rem;
}

nav ul {
    list-style: none;
    padding: 0;
}

nav ul li {
    display: inline-block;
    margin: 0 0.5rem;
    position: relative;
    text-align: left;
}

/* Nav Dropdown */
nav ul li:hover ul {
    display: block;
}

nav ul li ul {
    background: var(--color-bg);
    border: 1px solid var(--color-bg-secondary);
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow) var(--color-shadow);
    display: none;
    height: auto;
    left: -2px;
    padding: .5rem 1rem;
    position: absolute;
    top: 1.7rem;
    white-space: nowrap;
    width: auto;
    z-index: 1;
}

nav ul li ul::before {
    /* fill gap above to make mousing over them easier */
    content: "";
    position: absolute;
    left: 0;
    right: 0;
    top: -0.5rem;
    height: 0.5rem;
}

nav ul li ul li,
nav ul li ul li a {
    display: block;
}

/* Typography */
code,
samp {
    background-color: var(--color-accent);
    border-radius: var(--border-radius);
    color: var(--color-text);
    display: inline-block;
    margin: 0 0.1rem;
    padding: 0 0.5rem;
}

details {
    margin: 1.3rem 0;
}

details summary {
    font-weight: bold;
    cursor: pointer;
}

h1,
h2,
h3,
h4,
h5,
h6 {
    line-height: var(--line-height);
}

mark {
    padding: 0.1rem;
}

ol li,
ul li {
    padding: 0.2rem 0;
}

p {
    margin: 0.75rem 0;
    padding: 0;
}

pre {
    margin: 1rem 0;
    max-width: var(--width-card-wide);
    padding: 1rem 0;
}

pre code,
pre samp {
    display: block;
    max-width: var(--width-card-wide);
    padding: 0.5rem 2rem;
    white-space: pre-wrap;
}

small {
    color: var(--color-text-secondary);
}

sup {
    background-color: var(--color-secondary);
    border-radius: var(--border-radius);
    color: var(--color-bg);
    font-size: xx-small;
    font-weight: bold;
    margin: 0.2rem;
    padding: 0.2rem 0.3rem;
    position: relative;
    top: -2px;
}

/* Links */
a {
    color: var(--color-secondary);
    display: inline-block;
    text-decoration: none;
}

a:hover {
    filter: brightness(var(--hover-brightness));
    text-decoration: underline;
}

a b,
a em,
a i,
a strong,
button {
    border-radius: var(--border-radius);
    display: inline-block;
    font-size: medium;
    font-weight: bold;
    line-height: var(--line-height);
    margin: 0.5rem 0;
    padding: 1rem 2rem;
}

button {
    font-family: var(--font-family);
}

button:hover {
    cursor: pointer;
    filter: brightness(var(--hover-brightness));
}

a b,
a strong,
button {
    background-color: var(--color);
    border: 2px solid var(--color);
    color: var(--color-bg);
}

a em,
a i {
    border: 2px solid var(--color);
    border-radius: var(--border-radius);
    color: var(--color);
    display: inline-block;
    padding: 1rem 2rem;
}

/* Images */
figure {
    margin: 0;
    padding: 0;
}

figure img {
    max-width: 100%;
}

figure figcaption {
    color: var(--color-text-secondary);
}

/* Forms */

button:disabled,
input:disabled {
    background: var(--color-bg-secondary);
    border-color: var(--color-bg-secondary);
    color: var(--color-text-secondary);
    cursor: not-allowed;
}

button[disabled]:hover {
    filter: none;
}

form {
    border: 1px solid var(--color-bg-secondary);
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow) var(--color-shadow);
    display: block;
    max-width: var(--width-card-wide);
    min-width: var(--width-card);
    padding: 1.5rem;
    text-align: var(--justify-normal);
}

form header {
    margin: 1.5rem 0;
    padding: 1.5rem 0;
}

input,
label,
select,
textarea {
    display: block;
    font-size: inherit;
    max-width: var(--width-card-wide);
}

input[type="checkbox"],
input[type="radio"] {
    display: inline-block;
}

input[type="checkbox"]+label,
input[type="radio"]+label {
    display: inline-block;
    font-weight: normal;
    position: relative;
    top: 1px;
}

input,
select,
textarea {
    border: 1px solid var(--color-bg-secondary);
    border-radius: var(--border-radius);
    margin-bottom: 1rem;
    padding: 0.4rem 0.8rem;
}

input[readonly],
textarea[readonly] {
    background-color: var(--color-bg-secondary);
}

label {
    font-weight: bold;
    margin-bottom: 0.2rem;
}

/* Tables */
table {
    border: 1px solid var(--color-bg-secondary);
    border-radius: var(--border-radius);
    border-spacing: 0;
    display: inline-block;
    max-width: 100%;
    overflow-x: auto;
    padding: 0;
    white-space: nowrap;
}

table td,
table th,
table tr {
    padding: 0.4rem 0.8rem;
}

table thead {
    background-color: var(--color);
    border-collapse: collapse;
    border-radius: var(--border-radius);
    color: var(--color-bg);
    margin: 0;
    padding: 0;
}

table thead th:first-child {
    border-top-left-radius: var(--border-radius);
}

table thead th:last-child {
    border-top-right-radius: var(--border-radius);
}

table thead th:first-child,
table tr td:first-child {
    text-align: var(--justify-normal);
}

table tr:nth-child(even) {
    background-color: var(--color-accent);
}

/* Quotes */
blockquote {
    display: block;
    font-size: x-large;
    line-height: var(--line-height);
    margin: 1rem auto;
    max-width: var(--width-card-medium);
    padding: 1.5rem 1rem;
    text-align: var(--justify-important);
}

blockquote footer {
    color: var(--color-text-secondary);
    display: block;
    font-size: small;
    line-height: var(--line-height);
    padding: 1.5rem 0;
}
.mode { display: none; }
h2 { color: darkblue; }
h1, h3 { color: darkgreen; }

.tabbed {
    border-radius: 0;
    padding: 8px 16px;
    border: none;
}
.note {
    background: #ececec;
    margin: 15px;
    padding: 15px;
}
.box {
    background: white;
    border-style: solid;
    border-width: 1px;
    margin: 15px;
    padding: 15px;
}
.rect {
    color: black;
    background: lightgray;
    border-style: solid;
    border-width: 1px;
    width: 70px;
    margin: 5px;
    padding: 5px;
}
.content {
    display: flex;
    justify-content: space-between;
    align-items: top;
}
.ddhead {
    text-align: center;
    font-size: 20px;
    font-weight: bold;
}
.ddprogram {
    display:inline-block;
    width:200px;
    background: lightyellow;
    color: darkblue;
    padding-bottom: 5px;
    border-style: solid;
    border-width: 1px;
    text-align: center;
}
.text-up {
    text-align: center;
    font-size: 15px;
}

.highlight-border {
    border-left: solid 3px #000000;
    border-right: solid 3px #000000;
}

.highlight-border:before {
    border-top: solid 3px #000000;
    border-right: solid 3px #000000;
}

.highlight-border:after {
    border-bottom: solid 3px #000000;
    border-left: solid 3px #000000;
}

.bg-ugee { --color-bg: #1598bc; --color-text: white; }
.bg-leee { --color-bg: #e71d66; --color-text: white; }
.bg-boards { --color-bg: #54719e; --color-text: white; }
.bg-spec { --color-bg: #71549e; --color-text: white; }
.bg-oly { --color-bg: #38a84e; --color-text: white; }
.bg-dasa { --color-bg: #fa571b; --color-text: white; }
.bg-jee { --color-bg: #5a5a5c; --color-text: white; }

.hexagon, .hexagon:before, .hexagon:after, .hexagon span {
  background: var(--color-bg);
  /*--color: white;*/
}

.hexagon {
  width: 150px;
  height: 82.5px;
  position: relative;
}
	.title:hover{
		color:black;
	}

.hexagon:before,
.hexagon:after {
  content: "";
  position: absolute;
  left: 33px;
  width: 85.5px;
  height: 85.5px;
  transform: rotate(145deg) skew(22.5deg);
}

.hexagon:before {
  top: -43px;
}

.hexagon:after {
  top: 40.5px;
}

.hexagon span {
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  color: var(--color-text);
  top: 0;
  left: 0;
  width: 150px;
  height: 82.5px;
  font-size: 20px;
  z-index: 1;
}


.hexagon span small:hover{ 
	
 color:black !important;
	font-weight:bold !important;
}

/*.hexagon span small:hover :before {
  content: "Reply!"
}
*/
*/
.highlight-shadow, .highlight-shadow:before, .highlight-shadow:after {
   /* box-shadow: 0 0 20px rgba(0,255,255,1);*/
  /*box-shadow: 0 0 10px rgba(0,0,0,0.8);   */
}

/*new*/

/* .button */

.button {
    display: inline-block;
    position: relative;
    margin: 1em;
    padding: 0.67em;
    border: 2px solid #FFF;
    overflow: hidden;
    text-decoration: none;
    font-size: 2em;
    outline: none;
    color: #FFF;
    background: transparent;
    font-family: 'raleway', sans-serif;
}

.button span {
    -webkit-transition: 0.6s;
    -moz-transition: 0.6s;
    -o-transition: 0.6s;
    transition: 0.6s;
    -webkit-transition-delay: 0.2s;
    -moz-transition-delay: 0.2s;
    -o-transition-delay: 0.2s;
    transition-delay: 0.2s;
}

.button:before,
.button:after {
    content: '';
    position: absolute;
    top: 0.67em;
    left: 0;
    width: 100%;
    text-align: center;
    opacity: 0;
    -webkit-transition: .4s,opacity .6s;
    -moz-transition: .4s,opacity .6s;
    -o-transition: .4s,opacity .6s;
    transition: .4s,opacity .6s;
}

/* :before */

.button:before {
    content: attr(data-hover);
    -webkit-transform: translate(-150%,0);
    -moz-transform: translate(-150%,0);
    -ms-transform: translate(-150%,0);
    -o-transform: translate(-150%,0);
    transform: translate(-150%,0);
}

/* :after */

.button:after {
    content: attr(data-active);
    -webkit-transform: translate(150%,0);
    -moz-transform: translate(150%,0);
    -ms-transform: translate(150%,0);
    -o-transform: translate(150%,0);
    transform: translate(150%,0);
}

/* Span on :hover and :active */

.button:hover span,
.button:active span {
    opacity: 0;
    -webkit-transform: scale(0.3);
    -moz-transform: scale(0.3);
    -ms-transform: scale(0.3);
    -o-transform: scale(0.3);
    transform: scale(0.3);
}

/*  
    We show :before pseudo-element on :hover 
    and :after pseudo-element on :active 
*/

.button:hover:before,
.button:active:after {
    opacity: 1;
    -webkit-transform: translate(0,0);
    -moz-transform: translate(0,0);
    -ms-transform: translate(0,0);
    -o-transform: translate(0,0);
    transform: translate(0,0);
    -webkit-transition-delay: .4s;
    -moz-transition-delay: .4s;
    -o-transition-delay: .4s;
    transition-delay: .4s;
}

/* 
  We hide :before pseudo-element on :active
*/

.button:active:before {
    -webkit-transform: translate(-150%,0);
    -moz-transform: translate(-150%,0);
    -ms-transform: translate(-150%,0);
    -o-transform: translate(-150%,0);
    transform: translate(-150%,0);
    -webkit-transition-delay: 0s;
    -moz-transition-delay: 0s;
    -o-transition-delay: 0s;
    transition-delay: 0s;
}


/*new*/
.button1 {
    display: block;
    position: relative;
    padding: 10px 5px;
    overflow: hidden;
    text-decoration: none;
    
    outline: none;
    color: #FFF;
    background: transparent;
    width:150px;
    height:80px;
}

.button1 span {
    -webkit-transition: 0.2s;
    -moz-transition: 0.2s;
    -o-transition: 0.2s;
    transition: 0.2s;
    -webkit-transition-delay: 0.2s;
    -moz-transition-delay: 0.2s;
    -o-transition-delay: 0.2s;
    transition-delay: 0.2s;
    font-family: var(--font-family);
    font-size: 14px;
    font-weight: normal;
    
}

.button1:before,
.button1:after {
    content: '';
    position: absolute;
    top: 20px;
    left: 0;
    width: 100%;
    text-align: center;
    opacity: 0;
    -webkit-transition: .4s,opacity .6s;
    -moz-transition: .4s,opacity .6s;
    -o-transition: .4s,opacity .6s;
    transition: .4s,opacity .6s;
    font-family: var(--font-family);
    font-size: 14px;
    font-weight: normal;
}

/* :before */

.button1:before {
    content: attr(data-hover);
    -webkit-transform: translate(0,-150%);
    -moz-transform: translate(0,-150%);
    -ms-transform: translate(0,-150%);
    -o-transform: translate(0,-150%);
    transform: translate(0,-150%);
    font-family: var(--font-family);
    font-size: 16px;
    font-weight: bold;
    color:gold;
}

/* :after */

.button1:after {
    content: attr(data-active);
    -webkit-transform: translate(150%,0);
    -moz-transform: translate(150%,0);
    -ms-transform: translate(150%,0);
    -o-transform: translate(150%,0);
    transform: translate(150%,0);
}

/* Span on :hover and :active */

.button1:hover span,
.button1:active span {
    opacity: 0;
    -webkit-transform: translate(0,50%);
    -moz-transform: translate(0,50%);
    -ms-transform: translate(0,50%);
    -o-transform: translate(0,50%);
    transform: translate(0,150%);
}

/*  
    We show :before pseudo-element on :hover 
    and :after pseudo-element on :active 
*/

.button1:hover:before,
.button1:active:after {
    opacity: 1;
    -webkit-transform: translate(0,0);
    -moz-transform: translate(0,0);
    -ms-transform: translate(0,0);
    -o-transform: translate(0,0);
    transform: translate(0,0);
    -webkit-transition-delay: .4s;
    -moz-transition-delay: .4s;
    -o-transition-delay: .4s;
    transition-delay: .4s;
}

/* 
  We hide :before pseudo-element on :active
*/

.button1:active:before {
    -webkit-transform: translate(-150%,0);
    -moz-transform: translate(-150%,0);
    -ms-transform: translate(-150%,0);
    -o-transform: translate(-150%,0);
    transform: translate(-150%,0);
    -webkit-transition-delay: 0s;
    -moz-transition-delay: 0s;
    -o-transition-delay: 0s;
    transition-delay: 0s;
}

</style>
  <main id="main">
    <div class="ug-main">
      <div class="bd-main">
      <div class="bd-cont container">
        <div class="row">
        <div class="bg-ss">
        <div class="top-img">
          <div class="img-bar-top"></div>
          <img src="<?php echo $banner ?>" alt="Undergraduate Admissions" width="100%"  title="Undergraduate Admissions" class="Undergraduate-admissions-img">
          <div class="img-bar"></div>
		  
        </div>
         <br />

         <?php if( !empty( $announcement['top_announcement'] ) ): ?>
         <div id="covidnotes" class="note-con" style="background:#ffffe0;">
          <p class="note-para"> <?php echo $announcement['top_announcement'] ?> <br />
          <a data-toggle="collapse" data-target="#collapseNotes" href="#collapseNotes">...</a></p>

          <div id="collapseNotes" class="collapse" data-parent="#covidnotes">
          <?php
                  if( have_rows('announcement') ): ?>
           <?php while( have_rows('announcement') ) : the_row();?>
           <?php
                  if( have_rows('announcement_list') ): ?>
           <?php while( have_rows('announcement_list') ) : the_row();

                $content = get_sub_field('content');
                
                ?>
            <p class="note-para small"><?php echo $content?> <br />
            </p>
             <?php endwhile; ?>
            <?php endif; ?>
            <?php endwhile; ?>
            <?php endif; ?>
          </div>
          </div>
		  <?php endif; ?> 
        <div class="tg-down tg-left">
		<div class="col-9 mx-auto">
		<!--<div class="covid-note mb-5"><strong class="font-weights">Note: </strong>Undergraduate new admits physical reporting to the institute is scheduled on 28th October 2022</div> -->
		</div>
		
		<!-- experment -->
 
		 <!-- New Code -->
		 <?php
                  if( have_rows('modes_list') ): ?>
                    
		<div  style="padding:10px; width:100%;">
		<div class="d-flex align-items-center justify-content-center">
        <?php 
                      $rowcount = 0;
					  $i=0;
                      while( have_rows('modes_list') ) : the_row();
                        $rowcount = $rowcount+1;
						$i = $i+1;
                        $mode_title = get_sub_field('mode_title');
                        $mode_degree_info = get_sub_field('mode_degree_info');
                        $link = get_sub_field('link');
						$hex_bg= get_sub_field('hex_bg');
						$top_text= get_sub_field('top_text');
						$status_text= get_sub_field('status_text');
                    ?>
					
					  
                   
			  <?php if( !empty($link) ): ?>
				    <a href="<?php echo $link ?>">
				 <?php endif;?>
				 <?php    if($i<4){  echo "<div style='' >"; ?>
               <div class="content" style="justify-content:space-around; padding:40px 15px 40px 15px;border:1px solid #fff">
			     
				
					<a href="<?php echo $link ?>">
						<button class="hexagon <?php echo $hex_bg ?> ">
							<span>
								<div style="color:gold;margin:0px;padding:0px;">
									<?php echo $top_text ?><br />
									<small style="color:white; font-weight:normal; font-size:14px;">
									<?php echo $mode_title ?>
									</small>
									<br />
									<div style="color:lightgreen;font-weight:bold;font-size:18px;"><?php echo $status_text ?>
									</div>
								</div>
							</span>
						</button>
					</a>
					
					
				</div>
				 <?php  echo "</div>"  ?>
                  <?php } ?>
				  
				  <?php  if( !empty( $link ) ): ?>
				    </a>
				 <?php endif; ?> 
                 
			    <?php endwhile; ?>
			   
         </div></div>
		 <div  style="padding:10px; width:100%;">
		<div class="d-flex align-items-center justify-content-center">
        <?php 
                      $rowcount = 0;
					  $i=0;
                      while( have_rows('modes_list') ) : the_row();
                        $rowcount = $rowcount+1;
						$i = $i+1;
                        $mode_title = get_sub_field('mode_title');
                        $mode_degree_info = get_sub_field('mode_degree_info');
                        $link = get_sub_field('link');
						$hex_bg= get_sub_field('hex_bg');
						$top_text= get_sub_field('top_text');
						$status_text= get_sub_field('status_text');
                       

                    ?>
                    
			 
				   <?php    if($i>3){  echo "<div style='' >"; ?>
               <div class="content" style="justify-content:space-around; padding:40px 15px 40px 15px;">
					<a href="<?php echo $link ?>">
						<button class="hexagon <?php echo $hex_bg ?> ">
							<span>
								<div style="color:gold;margin:0px;padding:0px;">
									<?php echo $top_text ?><br />
									<small class="title" style="color:white; font-weight:normal; font-size:14px;">
									<?php echo $mode_title ?>
									</small>
									<br />
									<div style="color:lightgreen;font-weight:bold;font-size:18px;"><?php echo $status_text ?>
									</div>
								</div>
							</span>
						</button>
					</a>
				</div>
				 <?php  echo "</div>"  ?>
                  <?php } ?>
				  <?php  if( !empty( $link ) ): ?>
				    </a>
				 <?php endif; ?> 
                 
			    <?php endwhile; ?>
			   
         </div></div>
		
		
               <?php endif; ?>
		 
		 <!-- Old Code  -->
		 
        <ul class="tg-cont tg-up col-9 mx-auto" style="display:none">
        <?php
                  if( have_rows('modes_list') ): ?>
                    <?php 
                      $rowcount = 0;
                      while( have_rows('modes_list') ) : the_row();
                        $rowcount = $rowcount+1;
                        $mode_title = get_sub_field('mode_title');
                        $mode_degree_info = get_sub_field('mode_degree_info');
                        $link = get_sub_field('link');
                        $top_image = get_sub_field('top_image');
                        $bottom_image = get_sub_field('bottom_image');
                        
                        if($rowcount==4) {
                          echo "<li class='tg-sub left col-12 col-xl-3'>
                              <img src=wp-content/themes/Admissions/assets/img/left.png width='127' height='70' alt='' class='left-cs'>
                            </li>
                            <li class='tg-sub title col-12 col-xl-6'>
                              <h4 class='admissions'>Modes of Undergraduate Admissions</h4>
                            </li>
                            <li class='tg-sub right col-12 col-xl-3'>
                              <img src=wp-content/themes/Admissions/assets/img/right.png width='127' height='70' alt='' class='right-cs'>
                            </li>";
                        }

                    ?>
                  
              <li class="tg-sub col-12  col-sm-6 col-xl-4">
			  <?php if( !empty( $link ) ): ?>
				    <a href="<?php echo $link ?>">
				 <?php endif; ?>  
               
                  <img src="<?php echo $top_image ?>">
                  <div class="middle-te">
                  <h4 class="text-4"><?php echo $mode_title ?></h4>
                  <p class="st-para"><?php echo $mode_degree_info ?></p>
                  </div>
                  <img src="<?php echo $bottom_image ?>">
                  <?php if( !empty( $link ) ): ?>
				    </a>
				 <?php endif; ?> 
              </li>
                  
               <?php endwhile; ?>
               <?php endif; ?>
         </ul>
		 
           <!--<ul class="tg-cont tg-annc col-12 col-sm-12 col-md-4 col-xl-3">
            <div id="accordion">
               <div class="card">
                  <div class="card-header h-one">
                  <a class="card-link fadeInLeft" data-toggle="collapse" href="#collapseOne">
                    JEE (Main)
                  </a>
                  </div>
                  <div id="collapseOne" class="collapse show" data-parent="#accordion">
                  <div class="card-body">
                    <p class="portal-up">Will open in April 2020</p>
                  </div>
                  </div>
                </div>

                <div class="card">
                  <div class="card-header h-tw">
                  <a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseTwo">
                  (SPEC)
                  </a>
                  </div>
                  <div id="collapseTwo" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
              <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
              <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
                  </div>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header h-three">
                  <a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseThree">
                    (LEEE)
                  </a>
                  </div>
                  <div id="collapseThree" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
              <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
              <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
                  </div>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header h-four">
                  <a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapsefour">
                    Olympiad/KVPY
                  </a>
                  </div>
                  <div id="collapsefour" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
              <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
              <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
                  </div>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header h-five">
                  <a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseFive">
                    (DASA)
                  </a>
                  </div>
                  <div id="collapseFive" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
              <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
              <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
                  </div>
                  </div>
                </div>



                <div class="card">
                  <div class="card-header h-six">
                  <a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseSix">
                    JEE (Main)
                  </a>
                  </div>
                  <div id="collapseSix" class="collapse show" data-parent="#accordion">
                  <div class="card-body">
              <p class="portal-up">Round 4 Results Announced</p>
                  </div>
                  </div>
                </div>
                </div>
          </ul>-->
        </div>
          <div class="note-con">
          <p class="note-para"> <strong><?php echo $important_note_info['title'] ?></strong> <br><?php echo $important_note_info['important_note'] ?></p>
          </div>
        <div class= "youtube-links">
          <div class="hm-blog tg-cont">
        <div class="mg-sec-title">
          <h4><?php echo $videos_info['course_title'] ?></h4>
        </div>
          <div class="hm-blog-sub">
            <div class="row">
              <div class="col-md-4 section-one">
              <?php
              if( have_rows('videos_info') ): ?>
                <?php while( have_rows('videos_info') ) : the_row();

                ?>
              <?php
              if( have_rows('section_one') ): ?>
                <?php while( have_rows('section_one') ) : the_row();

                $main_title = get_sub_field('main_title');
                $title = get_sub_field('title');
                $url = get_sub_field('url');
                $image = get_sub_field('image');
                
                ?>
                <h4 class="bg-text"><?php echo $main_title ?></h4>
                <div class="inner-content">
                  <div class="image-section"><a href="<?php echo $url ?>"><img src="<?php echo $image ?>" width="174" height="114" alt=""></a></div>
                  <div class="text-up">
                    <a href="<?php echo $url ?>"><?php echo $title ?> </a>
                  </div>
                </div>
                <?php endwhile; ?>
                <?php endif; ?>
                <?php endwhile; ?>
                <?php endif; ?>
              </div>
            
            <div class="col-md-8 section-two">
            <?php
              if( have_rows('videos_info') ): ?>
                <?php while( have_rows('videos_info') ) : the_row();
                
                ?>
            <?php
              if( have_rows('section_two') ): ?>
                <?php while( have_rows('section_two') ) : the_row();
                $title = get_sub_field('title');
                
                ?>
             <h4 class="bg-text"><?php echo $title ?></h4>
             <div class="row">
            <?php
              if( have_rows('links_info') ): ?>
                <?php while( have_rows('links_info') ) : the_row();
                $image = get_sub_field('image');
                $link = get_sub_field('link');
                $title = get_sub_field('title');
                
                ?>
            
            <div class="inner-content col-md-4">
              <div class="image-section"><a href="<?php echo $link ?>"><img src="<?php echo $image ?>" width="174" height="114" alt=""></a></div>
              <div class="text-up">
                <a href="<?php echo $link ?>"><?php echo $title ?> </a>
              </div>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
            <?php endwhile; ?>
            <?php endif; ?>
            </div>
            </div>
            </div>
          </div>
        </div>
        <div class="row fee-structure">
        <?php
            if( have_rows('fee_structure') ): ?>
              <?php while( have_rows('fee_structure') ) : the_row();
              $information = get_sub_field('information');
              $link = get_sub_field('link');
              
              ?>
          
            <div class="fee-inner col-12 col-md-4">
              <a href="<?php echo $link ?>" class="fee-links"><?php echo $information ?></a>
            </div>
          <?php endwhile; ?>
          <?php endif; ?>
        </div> 
      </div>
       </div>
      </div>
    </div>
  </div>
  </main>
<?php wp_footer();?>
<?php get_footer();?>
<div class="ft-do"><?php echo $page_updated_month_and_year ?></div>
    
