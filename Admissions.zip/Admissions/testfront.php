<?php 
/* Template Name: fronttest*/
get_header();?>


<?php 
  $banner = get_field('banner');
  $announcement = get_field('announcement');
  $modes_list = get_field('announcement');
  $modes_list2 = get_field('modes_list2');
  $important_note_info =  get_field('important_note_info');
  $videos_info =  get_field('videos_info');
  $fee_structure =  get_field('fee_structure');
  $note_points =  get_field('note_points');
  $letest_news =  get_field('letest_news');
  $page_updated_month_and_year = get_field('page_updated_month_and_year');
  
            
?>
   <style>
        .img-bar-top {
            height: 21px;
            vertical-align: top;
            background-color: rgb(0, 59, 120);
        }
        
        .ug-main .img-bar {
            height: 18px;
            text-align: -webkit-left;
            vertical-align: top;
            background-color: rgb(204, 204, 204);
        }
        
        .hexagon {
            position: relative;
            display: inline-block;
            margin: 0 10px;
            text-align: center;
            overflow: hidden;
        }

        .hexagon img {
            width: 100%;
            height: auto;
            display: block;
        }

        .hexagon-inner {
            background-color: rgb(90, 90, 92);
            width: 100%;
            height: 50%;
            position: absolute;
            top: 25%;
            left: 0;
            clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0 75%, 0 25%);
        }
        .hexagon:hover{
            filter: brightness(1.50);
        }

        .hexagon-content {
            color: gold;
            text-align: center;
            font-size: 20px;
            font-weight: bold;
            position: absolute;
            top: 25%;
            left: 0;
            width: 100%;
        }

        .hexagon-content small {
            color: white;
            font-weight: normal;
            font-size: 14px;
            padding: 10px;
            display: block;
        }

        .hexagon-content h5 {
            color: lightgreen;
            font-weight: bold;
            font-size: 25px;
            margin-top: -10px;
        }

        /* Add border to the whole screen */
        body {
            border: 2px solid lightgray;
        }
        .important_note{
            background-color:#ececec;
            padding:10px;
            width:100%;
        }
        .dual-program{
           background-color: rgb(239, 242, 245);
           width:100%;
        }
        .heading{
            font-size:30px;
        }
        .responsive {
            max-width: 100%;
            height: auto;
            padding: 0 15px;
        }

        .gallery {
            display: inline-block;
            margin: 10px;
            
        }

        .gallery img {
            width: 100%;
            height: auto;
        }

      
        .info {
            color:blueviolet;
            font-size:bold;
            text-decoration: none;
        }

        .info:hover {
            color:blueviolet;
            text-decoration: underline;
        }
        .card{
            border: 1px solid lightgray;
        }
		.hexagon span small:hover{ 
	
 color:black !important;
	font-weight:bold !important;
}
		.bg-ugee { --color-bg: #1598bc; --color-text: white; }
.bg-leee { --color-bg: #e71d66; --color-text: white; }
.bg-boards { --color-bg: rgb(92, 123, 170); --color-text: white; }
.bg-spec { --color-bg: #71549e; --color-text: white; }
.bg-oly { --color-bg: #38a84e; --color-text: white; }
.bg-dasa { --color-bg: #fa571b; --color-text: white; }
.bg-jee { --color-bg: #5a5a5c; --color-text: white; }

.btn, .btn:before, .btn:after, .btn span {
  background: var(--color-bg);
  /*--color: white;*/
}
.button {
    display: inline-block;
    position: relative;
    margin: 1em;
    padding: 0.67em;
    border: 2px solid #FFF;
    overflow: hidden;
    text-decoration: none;
    font-size: 2em;
    outline: none;
    color: #FFF;
    background: transparent;
    font-family: 'raleway', sans-serif;
}
    </style>
  <main id="main">
    <div class="ug-main">
      <div class="bd-main">
      <div class="bd-cont container">
        <div class="row">
        <div class="bg-ss">
        <div class="top-img">
          <div class="img-bar-top"></div>
          <img src="<?php echo $banner ?>" alt="Undergraduate Admissions" width="100%"  title="Undergraduate Admissions" class="Undergraduate-admissions-img">
          <div class="img-bar"></div>
		  
        </div>
         <br />

         <?php if( !empty( $announcement['top_announcement'] ) ): ?>
         <div id="covidnotes" class="note-con" style="background:#ffffe0;">
          <p class="note-para"> <?php echo $announcement['top_announcement'] ?> <br />
          <a data-toggle="collapse" data-target="#collapseNotes" href="#collapseNotes">...</a></p>

          <div id="collapseNotes" class="collapse" data-parent="#covidnotes">
          <?php
                  if( have_rows('announcement') ): ?>
           <?php while( have_rows('announcement') ) : the_row();?>
           <?php
                  if( have_rows('announcement_list') ): ?>
           <?php while( have_rows('announcement_list') ) : the_row();

                $content = get_sub_field('content');
                
                ?>
            <p class="note-para small"><?php echo $content?> <br />
            </p>
             <?php endwhile; ?>
            <?php endif; ?>
            <?php endwhile; ?>
            <?php endif; ?>
          </div>
          </div>
		  <?php endif; ?> 
        <div class="tg-down tg-left">
		<div class="col-9 mx-auto">
		<!--<div class="covid-note mb-5"><strong class="font-weights">Note: </strong>Undergraduate new admits physical reporting to the institute is scheduled on 28th October 2022</div> -->
		</div>
		
		<!-- experment -->
 
		 <!-- New Code -->
		 <?php
                  if( have_rows('modes_list') ): ?>
                    
		<div  style="padding:10px; width:100%;">
		<div class="d-flex align-items-center justify-content-center">
        <?php 
                      $rowcount = 0;
					  $i=0;
                      while( have_rows('modes_list') ) : the_row();
                        $rowcount = $rowcount+1;
						$i = $i+1;
                        $mode_title = get_sub_field('mode_title');
                        $mode_degree_info = get_sub_field('mode_degree_info');
                        $link = get_sub_field('link');
						$hex_bg= get_sub_field('hex_bg');
						$top_text= get_sub_field('top_text');
						$status_text= get_sub_field('status_text');
						$top_image= get_sub_field('top_image');
						$bottom_image= get_sub_field('bottom_image');
                    ?>
					
					  
                   
			  <?php if( !empty($link) ): ?>
				    <a href="<?php echo $link ?>">
				 <?php endif;?>
				 <?php    if($i<4){  echo "<div style='' >"; ?>
               <div class="content" style="justify-content:space-around; padding:40px 15px 40px 15px;border:1px solid #fff">
			     
				
					<a href="<?php echo $link ?>">
						 <div class="hexagon" style="display:block;">
						  <img src="<?php echo $top_image ?>" style="width:180px;">
                           	<button class=" btn <?php echo $hex_bg ?> " style="width:180px;">
							<span>
								<div style="color:gold;margin:0px;padding:0px;font-weight:bold;font-size:20px;">
									<?php echo $top_text ?><br />
									<small style="color:white; font-weight:normal; font-size:14px;">
									<?php echo $mode_degree_info ?>
									</small>
									<br />
									<div style="color:lightgreen;font-weight:bold;;font-size:20px;"><?php echo $status_text ?>
									</div>
								</div>
							</span>
						</button>    
					      <img src="<?php echo $bottom_image ?>" style="width:180px;">
                          </div>
					</a>
					
					
				</div>
				 <?php  echo "</div>"  ?>
                  <?php } ?>
				  
				  <?php  if( !empty( $link ) ): ?>
				    </a>
				 <?php endif; ?> 
                 
			    <?php endwhile; ?>
			   
         </div></div>
		 <div  style="padding:10px; width:100%;">
		<div class="d-flex align-items-center justify-content-center">
        <?php 
                      $rowcount = 0;
					  $i=0;
                      while( have_rows('modes_list') ) : the_row();
                         $rowcount = $rowcount+1;
						$i = $i+1;
                        $mode_title = get_sub_field('mode_title');
                        $mode_degree_info = get_sub_field('mode_degree_info');
                        $link = get_sub_field('link');
						$hex_bg= get_sub_field('hex_bg');
						$top_text= get_sub_field('top_text');
						$status_text= get_sub_field('status_text');
						$top_image= get_sub_field('top_image');
						$bottom_image= get_sub_field('bottom_image');
                       

                    ?>
                    
			 
				   <?php    if($i>3){  echo "<div style='' >"; ?>
               <div class="content" style="justify-content:space-around; padding:40px 15px 40px 15px;">
					<a href="<?php echo $link ?>">
						 <div class="hexagon" style="display:block;">
						  <img src="<?php echo $top_image ?>" style="width:180px;">
                           	<button class=" btn <?php echo $hex_bg ?> " style="width:180px;">
							<span>
								<div style="color:gold;margin:0px;padding:0px;font-weight:bold;font-size:20px;">
									<?php echo $top_text ?><br />
									<small style="color:white; font-weight:normal; font-size:14px;">
									<?php echo $mode_degree_info ?>
									</small>
									<br />
									<div style="color:lightgreen;font-weight:bold;;font-size:20px;"><?php echo $status_text ?>
									</div>
								</div>
							</span>
						</button>    
					      <img src="<?php echo $bottom_image ?>" style="width:180px;">
                          </div>
					</a>
				</div>
				 <?php  echo "</div>"  ?>
                  <?php } ?>
				  <?php  if( !empty( $link ) ): ?>
				    </a>
				 <?php endif; ?> 
                 
			    <?php endwhile; ?>
			   
         </div></div>
		
		
               <?php endif; ?>
		 
		 <!-- Old Code  -->
		 
        <ul class="tg-cont tg-up col-9 mx-auto" style="display:none">
        <?php
                  if( have_rows('modes_list') ): ?>
                    <?php 
                      $rowcount = 0;
                      while( have_rows('modes_list') ) : the_row();
                        $rowcount = $rowcount+1;
                        $mode_title = get_sub_field('mode_title');
                        $mode_degree_info = get_sub_field('mode_degree_info');
                        $link = get_sub_field('link');
                        $top_image = get_sub_field('top_image');
                        $bottom_image = get_sub_field('bottom_image');
                        
                        if($rowcount==4) {
                          echo "<li class='tg-sub left col-12 col-xl-3'>
                              <img src=wp-content/themes/Admissions/assets/img/left.png width='127' height='70' alt='' class='left-cs'>
                            </li>
                            <li class='tg-sub title col-12 col-xl-6'>
                              <h4 class='admissions'>Modes of Undergraduate Admissions</h4>
                            </li>
                            <li class='tg-sub right col-12 col-xl-3'>
                              <img src=wp-content/themes/Admissions/assets/img/right.png width='127' height='70' alt='' class='right-cs'>
                            </li>";
                        }

                    ?>
                  
              <li class="tg-sub col-12  col-sm-6 col-xl-4">
			  <?php if( !empty( $link ) ): ?>
				    <a href="<?php echo $link ?>">
				 <?php endif; ?>  
               
                  <img src="<?php echo $top_image ?>">
                  <div class="middle-te">
                  <h4 class="text-4"><?php echo $mode_title ?></h4>
                  <p class="st-para"><?php echo $mode_degree_info ?></p>
                  </div>
                  <img src="<?php echo $bottom_image ?>">
                  <?php if( !empty( $link ) ): ?>
				    </a>
				 <?php endif; ?> 
              </li>
                  
               <?php endwhile; ?>
               <?php endif; ?>
         </ul>
		 
           <!--<ul class="tg-cont tg-annc col-12 col-sm-12 col-md-4 col-xl-3">
            <div id="accordion">
               <div class="card">
                  <div class="card-header h-one">
                  <a class="card-link fadeInLeft" data-toggle="collapse" href="#collapseOne">
                    JEE (Main)
                  </a>
                  </div>
                  <div id="collapseOne" class="collapse show" data-parent="#accordion">
                  <div class="card-body">
                    <p class="portal-up">Will open in April 2020</p>
                  </div>
                  </div>
                </div>

                <div class="card">
                  <div class="card-header h-tw">
                  <a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseTwo">
                  (SPEC)
                  </a>
                  </div>
                  <div id="collapseTwo" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
              <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
              <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
                  </div>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header h-three">
                  <a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseThree">
                    (LEEE)
                  </a>
                  </div>
                  <div id="collapseThree" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
              <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
              <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
                  </div>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header h-four">
                  <a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapsefour">
                    Olympiad/KVPY
                  </a>
                  </div>
                  <div id="collapsefour" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
              <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
              <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
                  </div>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header h-five">
                  <a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseFive">
                    (DASA)
                  </a>
                  </div>
                  <div id="collapseFive" class="collapse" data-parent="#accordion">
                  <div class="card-body">
                    <p class="portal-up">Application Portal Opens: 6th Feb 2020</p>
              <p class="portal-up">Application Portal Closes: 31st Mar 2020</p>
              <p class="portal-up">Entrance Exam - 26th Apr 2020</p>
                  </div>
                  </div>
                </div>



                <div class="card">
                  <div class="card-header h-six">
                  <a class="collapsed card-link fadeInLeft" data-toggle="collapse" href="#collapseSix">
                    JEE (Main)
                  </a>
                  </div>
                  <div id="collapseSix" class="collapse show" data-parent="#accordion">
                  <div class="card-body">
              <p class="portal-up">Round 4 Results Announced</p>
                  </div>
                  </div>
                </div>
                </div>
          </ul>-->
        </div>
          <div class="note-con">
          <p class="note-para"> <strong><?php echo $important_note_info['title'] ?></strong> <br><?php echo $important_note_info['important_note'] ?></p>
          </div>
        <div class= "youtube-links">
          <div class="hm-blog tg-cont">
        <div class="mg-sec-title">
          <h4><?php echo $videos_info['course_title'] ?></h4>
        </div>
          <div class="hm-blog-sub">
            <div class="row">
              <div class="col-md-4 section-one">
              <?php
              if( have_rows('videos_info') ): ?>
                <?php while( have_rows('videos_info') ) : the_row();

                ?>
              <?php
              if( have_rows('section_one') ): ?>
                <?php while( have_rows('section_one') ) : the_row();

                $main_title = get_sub_field('main_title');
                $title = get_sub_field('title');
                $url = get_sub_field('url');
                $image = get_sub_field('image');
                
                ?>
                <h4 class="bg-text"><?php echo $main_title ?></h4>
                <div class="inner-content">
                  <div class="image-section"><a href="<?php echo $url ?>"><img src="<?php echo $image ?>" width="174" height="114" alt=""></a></div>
                  <div class="text-up">
                    <a href="<?php echo $url ?>"><?php echo $title ?> </a>
                  </div>
                </div>
                <?php endwhile; ?>
                <?php endif; ?>
                <?php endwhile; ?>
                <?php endif; ?>
              </div>
            
            <div class="col-md-8 section-two">
            <?php
              if( have_rows('videos_info') ): ?>
                <?php while( have_rows('videos_info') ) : the_row();
                
                ?>
            <?php
              if( have_rows('section_two') ): ?>
                <?php while( have_rows('section_two') ) : the_row();
                $title = get_sub_field('title');
                
                ?>
             <h4 class="bg-text"><?php echo $title ?></h4>
             <div class="row">
            <?php
              if( have_rows('links_info') ): ?>
                <?php while( have_rows('links_info') ) : the_row();
                $image = get_sub_field('image');
                $link = get_sub_field('link');
                $title = get_sub_field('title');
                
                ?>
            
            <div class="inner-content col-md-4">
              <div class="image-section"><a href="<?php echo $link ?>"><img src="<?php echo $image ?>" width="174" height="114" alt=""></a></div>
              <div class="text-up">
                <a href="<?php echo $link ?>"><?php echo $title ?> </a>
              </div>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
            <?php endwhile; ?>
            <?php endif; ?>
            </div>
            </div>
            </div>
          </div>
        </div>
        <div class="row fee-structure">
        <?php
            if( have_rows('fee_structure') ): ?>
              <?php while( have_rows('fee_structure') ) : the_row();
              $information = get_sub_field('information');
              $link = get_sub_field('link');
              
              ?>
          
            <div class="fee-inner col-12 col-md-4">
              <a href="<?php echo $link ?>" class="fee-links"><?php echo $information ?></a>
            </div>
          <?php endwhile; ?>
          <?php endif; ?>
        </div> 
      </div>
       </div>
      </div>
    </div>
  </div>
  </main>
<?php wp_footer();?>
<?php get_footer();?>
<div class="ft-do"><?php echo $page_updated_month_and_year ?></div>
    


    
