<?php

function square_add_excerpt_support_for_pages() {
    add_post_type_support('page', 'excerpt');
}

add_action('init', 'square_add_excerpt_support_for_pages');


function load_stylesheets() {
	
	wp_register_style('bootstrap',get_template_directory_uri() . '/assets/vendor/bootstrap/css/bootstrap.min.css', array(),1,'all');
	wp_enqueue_style('bootstrap');

	wp_register_style('font-awesome',get_template_directory_uri() . '/assets/vendor/font-awesome/css/font-awesome.min.css', array(),1,'all');
	wp_enqueue_style('font-awesome');

	wp_register_style('edit_styles',get_template_directory_uri() . '/assets/css/styles.css?v=1.5', array(),1,'all');
	wp_enqueue_style('edit_styles');


}


add_action('wp_enqueue_scripts', 'load_stylesheets');


//load scripts

function addjs() {
	wp_enqueue_script( 'jquery', get_template_directory_uri() . '/assets/vendor/jquery/jquery.min.js" type="text/javascript', array('jquery'), '3.2', true );
	
	wp_register_script('bootstrap_bundle',get_template_directory_uri() . '/assets/vendor/bootstrap/js/bootstrap.bundle.min.js', array() ,1 ,1 ,1);
	wp_enqueue_script('bootstrap_bundle');

	wp_register_script('jquery_easing',get_template_directory_uri() . '/assets/vendor/jquery.easing/jquery.easing.min.js', array() ,1 ,1 ,1);
	wp_enqueue_script('jquery_easing');

	wp_register_script('main',get_template_directory_uri() . '/assets/js/main.js', array() ,1 ,1 ,1);
	wp_enqueue_script('main');
	
	

}

add_action('wp_enqueue_scripts', 'addjs');

//Menu supoort
add_theme_support('menus');

//Register Menus
register_nav_menus(

	array(

		'top-menu' =>  'Top Menu Location',
		'mobile-menu' => 'Mobile Menu Location' ,
	)

);

?>